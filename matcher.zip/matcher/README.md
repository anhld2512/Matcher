Tuyệt vời, để đáp ứng yêu cầu "dễ hiểu, dòng hàng rõ ràng", tôi sẽ tối ưu lại bố cục. Tôi sẽ sử dụng bảng (table) và gạch đầu dòng nhiều hơn để mắt dễ nhìn, tách biệt tiếng Anh và tiếng Việt rõ ràng.

Dưới đây là phiên bản README.md mới:

🎯 Matcher Application
Automated CV Screening with AI – Supports Ollama, Gemini, ChatGPT, DeepSeek, HuggingFace.


Đánh giá CV tự động bằng AI – Hỗ trợ đa nền tảng AI với giao diện Web và xử lý ngầm.

⚡ Quick Start / Khởi chạy nhanh
macOS / Linux: Run this single command to install everything (Python, Redis, Ollama) and start the app.


Chạy một lệnh duy nhất để cài đặt toàn bộ (Python, Redis, Ollama) và khởi động ứng dụng.

cd cv-jd-matcher
./run.sh

 Scripts / Các lệnh điều khiểnCommand (Lệnh)Description (Tiếng Anh)Mô tả (Tiếng Việt)./run.shAuto-Setup & Start (Recommended)Cài đặt & Chạy (Khuyên dùng)./start.shStart services onlyChỉ khởi động (nếu đã cài đặt)./stop.shStop all servicesDừng tất cả chương trình./setup.shInstall dependencies onlyChỉ cài đặt thư viện (không chạy)